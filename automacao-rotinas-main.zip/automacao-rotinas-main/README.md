# Automação de Rotinas — Gerador de Relatório de Vendas

Script que **elimina uma tarefa manual repetitiva**: transformar uma planilha de vendas em um relatório pronto, com indicadores e gráficos, em segundos.

> **Problema:** processos repetitivos (consolidar vendas, calcular totais, montar relatório) consumiam horas por semana.
> **Solução:** um script que lê o CSV, calcula tudo e gera um relatório formatado automaticamente.
> **Resultado:** economia de tempo e eliminação de erros de digitação/soma.

## O que ele faz

A partir de um arquivo `.csv` de vendas, o script gera:

1. **Resumo no terminal** — faturamento, ticket médio, ranking de vendedores e top produtos.
2. **Relatório HTML** (`relatorio.html`) — com cards de indicadores, gráficos de barras e tabela de produtos, pronto para abrir no navegador ou enviar ao cliente.

## Destaques técnicos

- **Somente biblioteca padrão** do Python (`csv`, `datetime`, `collections`, `argparse`) — nada para instalar.
- **Validação linha a linha:** registros inválidos são avisados e ignorados, sem derrubar a execução.
- **Formatação pt-BR / BRL** (R$ 1.234,56).
- **Parâmetros via linha de comando** (`--entrada`, `--saida`).
- Saída **UTF-8** compatível com o terminal do Windows.
- Relatório HTML **autossuficiente** (CSS embutido, sem dependências).

## Como rodar

```bash
# com os dados de exemplo
python gerar_relatorio.py

# apontando para outro arquivo / saída
python gerar_relatorio.py --entrada dados/vendas.csv --saida junho.html
```

Depois, abra o `relatorio.html` gerado no navegador.

## Formato do CSV de entrada

```csv
data,produto,categoria,quantidade,valor_unitario,vendedor
2026-06-01,Consultoria de Automação,Serviços,1,1500.00,Ana
```

| Coluna | Descrição |
|--------|-----------|
| `data` | Data da venda no formato `AAAA-MM-DD` |
| `produto` | Nome do produto ou serviço |
| `categoria` | Categoria para agrupamento |
| `quantidade` | Quantidade vendida (inteiro) |
| `valor_unitario` | Preço unitário (decimal com ponto) |
| `vendedor` | Responsável pela venda |

## Estrutura

```
automacao-rotinas/
├── gerar_relatorio.py
├── dados/
│   └── vendas.csv      # dados de exemplo
└── relatorio.html      # gerado ao executar
```

## Ideia de evolução

Este script pode ser agendado (Agendador de Tarefas do Windows ou `cron`) para rodar
todo dia/semana e enviar o relatório por e-mail automaticamente.
