#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Automação de Rotinas — Gerador de Relatório de Vendas
=====================================================
Lê um arquivo CSV de vendas, calcula indicadores e gera:
  1. Um resumo no terminal
  2. Um relatório HTML pronto para abrir no navegador

Usa apenas a biblioteca padrão do Python (sem dependências externas).

Uso:
    python gerar_relatorio.py
    python gerar_relatorio.py --entrada dados/vendas.csv --saida relatorio.html
"""

import argparse
import csv
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

# Garante saída UTF-8 no terminal (evita erro no console do Windows / cp1252).
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

MESES = ["", "janeiro", "fevereiro", "março", "abril", "maio", "junho",
         "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"]


def brl(valor: float) -> str:
    """Formata número no padrão monetário brasileiro (R$ 1.234,56)."""
    return "R$ " + f"{valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def carregar_vendas(caminho: Path) -> list[dict]:
    """Lê o CSV e devolve uma lista de vendas já com o total calculado."""
    if not caminho.exists():
        raise FileNotFoundError(f"Arquivo não encontrado: {caminho}")

    vendas = []
    with caminho.open(encoding="utf-8") as f:
        for linha, registro in enumerate(csv.DictReader(f), start=2):
            try:
                qtd = int(registro["quantidade"])
                unit = float(registro["valor_unitario"])
                vendas.append({
                    "data": datetime.strptime(registro["data"], "%Y-%m-%d").date(),
                    "produto": registro["produto"].strip(),
                    "categoria": registro["categoria"].strip(),
                    "quantidade": qtd,
                    "valor_unitario": unit,
                    "vendedor": registro["vendedor"].strip(),
                    "total": qtd * unit,
                })
            except (ValueError, KeyError) as erro:
                print(f"  ⚠ linha {linha} ignorada (dado inválido): {erro}")
    return vendas


def resumir(vendas: list[dict]) -> dict:
    """Consolida os principais indicadores a partir da lista de vendas."""
    faturamento = sum(v["total"] for v in vendas)
    itens = sum(v["quantidade"] for v in vendas)

    por_categoria = defaultdict(float)
    por_vendedor = defaultdict(float)
    por_produto = defaultdict(lambda: {"qtd": 0, "total": 0.0})

    for v in vendas:
        por_categoria[v["categoria"]] += v["total"]
        por_vendedor[v["vendedor"]] += v["total"]
        por_produto[v["produto"]]["qtd"] += v["quantidade"]
        por_produto[v["produto"]]["total"] += v["total"]

    top_produtos = sorted(
        por_produto.items(), key=lambda kv: kv[1]["total"], reverse=True
    )

    return {
        "n_vendas": len(vendas),
        "faturamento": faturamento,
        "itens": itens,
        "ticket_medio": faturamento / len(vendas) if vendas else 0,
        "por_categoria": dict(sorted(por_categoria.items(), key=lambda kv: kv[1], reverse=True)),
        "por_vendedor": dict(sorted(por_vendedor.items(), key=lambda kv: kv[1], reverse=True)),
        "top_produtos": top_produtos,
        "periodo": (min(v["data"] for v in vendas), max(v["data"] for v in vendas)) if vendas else None,
    }


def imprimir_resumo(r: dict) -> None:
    """Mostra o resumo formatado no terminal."""
    print("\n" + "=" * 52)
    print("  RELATÓRIO DE VENDAS")
    print("=" * 52)
    if r["periodo"]:
        ini, fim = r["periodo"]
        print(f"  Período .......... {ini.strftime('%d/%m/%Y')} a {fim.strftime('%d/%m/%Y')}")
    print(f"  Vendas ........... {r['n_vendas']}")
    print(f"  Itens vendidos ... {r['itens']}")
    print(f"  Faturamento ...... {brl(r['faturamento'])}")
    print(f"  Ticket médio ..... {brl(r['ticket_medio'])}")

    print("\n  Faturamento por categoria:")
    for cat, val in r["por_categoria"].items():
        print(f"    - {cat:<12} {brl(val)}")

    print("\n  Ranking de vendedores:")
    for i, (vend, val) in enumerate(r["por_vendedor"].items(), 1):
        print(f"    {i}. {vend:<10} {brl(val)}")

    print("\n  Top produtos:")
    for prod, d in r["top_produtos"][:3]:
        print(f"    - {prod:<28} {brl(d['total'])}  ({d['qtd']} un.)")
    print("=" * 52 + "\n")


def gerar_html(r: dict, saida: Path) -> None:
    """Grava um relatório HTML autossuficiente (estilo embutido)."""
    hoje = datetime.now()
    periodo = ""
    if r["periodo"]:
        ini, fim = r["periodo"]
        periodo = f"{ini.strftime('%d/%m/%Y')} — {fim.strftime('%d/%m/%Y')}"

    def barras(dados: dict) -> str:
        maior = max(dados.values()) if dados else 1
        linhas = ""
        for nome, val in dados.items():
            pct = (val / maior) * 100
            linhas += (
                f'<div class="bar-row"><span class="bar-label">{nome}</span>'
                f'<div class="bar-track"><div class="bar-fill" style="width:{pct:.1f}%"></div></div>'
                f'<span class="bar-val">{brl(val)}</span></div>'
            )
        return linhas

    cards = "".join(
        f'<div class="card"><span>{titulo}</span><strong>{valor}</strong></div>'
        for titulo, valor in [
            ("Faturamento", brl(r["faturamento"])),
            ("Vendas", str(r["n_vendas"])),
            ("Itens vendidos", str(r["itens"])),
            ("Ticket médio", brl(r["ticket_medio"])),
        ]
    )

    produtos = "".join(
        f"<tr><td>{prod}</td><td>{d['qtd']}</td><td>{brl(d['total'])}</td></tr>"
        for prod, d in r["top_produtos"]
    )

    html = f"""<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Relatório de Vendas — {periodo}</title>
<style>
  :root {{ --bg:#0b0f14; --card:#131a23; --border:#1f2836; --text:#e7edf3; --soft:#a7b4c2; --accent:#38bdf8; --accent2:#2dd4bf; }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; font-family:'Segoe UI',system-ui,sans-serif; background:var(--bg); color:var(--text); padding:40px 20px; }}
  .wrap {{ max-width:840px; margin:0 auto; }}
  h1 {{ font-size:1.6rem; margin:0 0 4px; }}
  .sub {{ color:var(--soft); margin:0 0 28px; font-size:0.9rem; }}
  .cards {{ display:grid; grid-template-columns:repeat(4,1fr); gap:14px; margin-bottom:32px; }}
  .card {{ background:var(--card); border:1px solid var(--border); border-radius:14px; padding:18px; }}
  .card span {{ display:block; color:var(--soft); font-size:0.78rem; }}
  .card strong {{ font-size:1.3rem; }}
  h2 {{ font-size:1.05rem; margin:28px 0 14px; }}
  .bar-row {{ display:grid; grid-template-columns:130px 1fr 120px; align-items:center; gap:12px; margin-bottom:10px; }}
  .bar-label {{ font-size:0.85rem; color:var(--soft); }}
  .bar-track {{ background:var(--border); border-radius:99px; height:12px; overflow:hidden; }}
  .bar-fill {{ height:100%; background:linear-gradient(90deg,var(--accent),var(--accent2)); border-radius:99px; }}
  .bar-val {{ font-size:0.85rem; text-align:right; font-variant-numeric:tabular-nums; }}
  table {{ width:100%; border-collapse:collapse; margin-top:8px; }}
  th,td {{ text-align:left; padding:10px 12px; border-bottom:1px solid var(--border); font-size:0.9rem; }}
  th {{ color:var(--soft); font-weight:600; }}
  td:nth-child(2),td:nth-child(3),th:nth-child(2),th:nth-child(3) {{ text-align:right; }}
  .foot {{ margin-top:32px; color:#6b7889; font-size:0.78rem; }}
  @media (max-width:640px) {{ .cards {{ grid-template-columns:repeat(2,1fr); }} .bar-row {{ grid-template-columns:90px 1fr; }} .bar-val {{ display:none; }} }}
</style></head>
<body><div class="wrap">
  <h1>Relatório de Vendas</h1>
  <p class="sub">Período: {periodo} &nbsp;•&nbsp; gerado em {hoje.strftime('%d/%m/%Y às %H:%M')}</p>
  <div class="cards">{cards}</div>
  <h2>Faturamento por categoria</h2>{barras(r['por_categoria'])}
  <h2>Ranking de vendedores</h2>{barras(r['por_vendedor'])}
  <h2>Produtos</h2>
  <table><thead><tr><th>Produto</th><th>Qtd.</th><th>Total</th></tr></thead><tbody>{produtos}</tbody></table>
  <p class="foot">Relatório gerado automaticamente por gerar_relatorio.py</p>
</div></body></html>"""

    saida.write_text(html, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Gera relatório de vendas a partir de um CSV.")
    parser.add_argument("--entrada", default="dados/vendas.csv", help="Caminho do CSV de entrada.")
    parser.add_argument("--saida", default="relatorio.html", help="Arquivo HTML de saída.")
    args = parser.parse_args()

    base = Path(__file__).parent
    entrada = (base / args.entrada) if not Path(args.entrada).is_absolute() else Path(args.entrada)
    saida = (base / args.saida) if not Path(args.saida).is_absolute() else Path(args.saida)

    print(f"→ Lendo {entrada} …")
    vendas = carregar_vendas(entrada)
    if not vendas:
        print("Nenhuma venda válida encontrada. Encerrando.")
        return

    resumo = resumir(vendas)
    imprimir_resumo(resumo)
    gerar_html(resumo, saida)
    print(f"✓ Relatório HTML gerado: {saida}\n")


if __name__ == "__main__":
    main()
